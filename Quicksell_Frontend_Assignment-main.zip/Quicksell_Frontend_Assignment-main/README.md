
## Demo


## 🚀 About Me
I am Suryansh Verma, a Bachelor of Technology student majoring in Computer Science Enginering at the prestigious GLA University. 


## Tech Stack

**Client:** React

**Server:**


## Run Locally

Clone the project

```bash
  git clone
```

Install dependencies

```bash
  npm install
```

Start the client

```bash
  npm start
```
